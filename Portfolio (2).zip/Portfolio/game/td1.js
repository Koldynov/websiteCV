var config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    scene: {
        preload: preload,
        create: create,
        update: update
    },
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 300 },
            debug: false
        }
    }
};

var game = new Phaser.Game(config);
var score = 0;
var scoreText;
var waveCount = 0;
var bombs;  
var stars;  
var player;
var platforms;
var cursors;

function preload() {
    this.load.image('sky', 'assets/sky2.png');
    this.load.image('ground', 'assets/platform.png');
    this.load.image('star', 'assets/star.png');
    this.load.image('bomb', 'assets/bomb.png');
    this.load.spritesheet('dude', 'assets/dude.png', { frameWidth: 32, frameHeight: 48 });
}

function create() {
    this.add.image(400, 300, 'sky');
    platforms = this.physics.add.staticGroup();
    platforms.create(400, 568, 'ground').setScale(2).refreshBody();
    platforms.create(600, 400, 'ground');
    platforms.create(50, 250, 'ground');
    platforms.create(750, 220, 'ground');
    player = this.physics.add.sprite(100, 450, 'dude');
    stars = this.physics.add.group({
        key: 'star',
        repeat: 11,
        setXY: { x: 12, y: 0, stepX: 70 }
    });
    player.setBounce(0.2);
    player.setCollideWorldBounds(true);

    stars.children.iterate(function (child) {
        child.setBounceY(Phaser.Math.FloatBetween(0.4, 0.8));
    });

    this.physics.add.overlap(player, stars, collectStar, null, this);
    this.anims.create({
        key: 'left',
        frames: this.anims.generateFrameNumbers('dude', { start: 0, end: 3 }),
        frameRate: 10,
        repeat: -1
    });
    this.anims.create({
        key: 'right',
        frames: this.anims.generateFrameNumbers('dude', { start: 5, end: 8 }),
        frameRate: 10,
        repeat: -1
    });
    this.anims.create({
        key: 'turn',
        frames: this.anims.generateFrameNumbers('dude', { start: 4, end: 4 }),
        frameRate: 10,
        repeat: -1
    });
    player.body.setGravityY(300);
    this.physics.add.collider(player, platforms);
    this.physics.add.collider(stars, platforms);
    cursors = this.input.keyboard.createCursorKeys();
    scoreText = this.add.text(16, 16, 'Score: 0', {
        fontSize: '32px',
        fill: '#000'
    });
    startWave(this);
}

function startWave(scene) {
    waveCount++;  

    scoreText.setText('Score: ' + score);

    if (stars) stars.clear(true, true);
    if (bombs) bombs.clear(true, true);

    stars = scene.physics.add.group({
        key: 'star',
        repeat: 11,  
        setXY: { x: 12, y: 0, stepX: 70 }
    });

    stars.children.iterate(function (child) {
        child.setBounceY(Phaser.Math.FloatBetween(0.4, 0.8));
    });

    bombs = scene.physics.add.group();

    var currentBombCount = Math.min(waveCount, 6);

    for (var i = 0; i < currentBombCount; i++) {
        var bomb = bombs.create(Phaser.Math.Between(0, 800), 0, 'bomb');
        bomb.setBounce(1);
        bomb.setCollideWorldBounds(true);
        bomb.setVelocity(Phaser.Math.Between(-200, 200), 20);
    }

    scene.physics.add.overlap(player, stars, collectStar, null, scene);
    scene.physics.add.collider(player, platforms);
    scene.physics.add.collider(stars, platforms);
    scene.physics.add.collider(bombs, platforms);
    scene.physics.add.collider(player, bombs, hitBomb, null, scene);
}

function update() {
    if (cursors.up.isDown && player.body.touching.down) {
        player.setVelocityY(-500);
    }
    if (cursors.left.isDown) {
        player.setVelocityX(-160);
        player.anims.play('left', true);
    } else if (cursors.right.isDown) {
        player.setVelocityX(160);
        player.anims.play('right', true);
    } else {
        player.setVelocityX(0);
        player.anims.play('turn');
    }

    if (stars.countActive(true) === 0) {
        startWave(this);
    }
}

function collectStar(player, star) {
    star.disableBody(true, true);
    score += 10;
    scoreText.setText('Score: ' + score);
}

function hitBomb(player, bomb) {
    this.physics.pause();
    player.setTint(0xff0000); 
    player.anims.play('turn');
    scoreText.setText('GAME OVER\nFinal Score: ' + score);
}